from django.core.files.storage import FileSystemStorage
from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, render
from django.http import Http404, HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse, reverse_lazy
from django.utils import timezone
import datetime
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.utils.datastructures import MultiValueDictKeyError
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth import logout
from django.shortcuts import redirect
from django.contrib.auth.decorators import login_required, permission_required

from .models import Questao, Opcao, Aluno, Foto

def index(request):
    try:
        latest_question_list = Questao.objects.all()
        uploaded_file_url = request.user.foto.foto_url
        return render(request, 'votacao/index.html', {'latest_question_list': latest_question_list, 'uploaded_file_url': uploaded_file_url})
    except ObjectDoesNotExist:
        latest_question_list = Questao.objects.all()
        return render(request, 'votacao/index.html', {'latest_question_list': latest_question_list})

def detalhe(request, questao_id):
    questao = get_object_or_404(Questao, pk=questao_id)
    return render(request, 'votacao/detalhe.html', {'questao': questao})

@login_required(login_url='/votacao/iniciarsessao')
def voto(request, questao_id):
    questao = get_object_or_404(Questao, pk=questao_id)
    try:
        opcao_seleccionada = questao.opcao_set.get(pk=request.POST['opcao'])
    except (KeyError, Opcao.DoesNotExist):
    # Apresenta de novo o form para votar
        return render(request, 'votacao/detalhe.html', {'questao': questao, 'error_message': "Não escolheu uma opção",})
    else:
        opcao_seleccionada.votos += 1
        opcao_seleccionada.save()
 # Retorne sempre HttpResponseRedirect depois de
 # tratar os dados POST de um form
 # pois isso impede os dados de serem tratados
 # repetidamente se o utilizador
 # voltar para a página web anterior.
        return HttpResponseRedirect(reverse('votacao:resultados', args=(questao.id,)))

def resultados(request, questao_id):
    questao = get_object_or_404(Questao, pk=questao_id)
    return render(request, 'votacao/resultados.html', {'questao': questao})

@permission_required('votacao.add_questao', login_url=reverse_lazy('votacao:iniciarsessao'))
def view_questao_otimizada(request):
    if request.method == 'POST':
        questao_texto = request.POST['questao']
        pub_data = timezone.now()
        q = Questao(questao_texto=questao_texto, pub_data=pub_data)
        q.save()
        return HttpResponseRedirect(reverse('votacao:index'))
    else:
        return render(request, 'votacao/criarquestao.html')

@permission_required('votacao.add_opcao', login_url=reverse_lazy('votacao:iniciarsessao'))
def view_opcao_otimizada(request, questao_id):
    if request.method == 'POST':
        questao = Questao.objects.get(pk=questao_id)
        questao.opcao_set.create(opcao_texto=request.POST['opcao'], votos=0)
        return HttpResponseRedirect(reverse('votacao:detalhe', args=(questao.id,)))
    else:
        questao = get_object_or_404(Questao, pk=questao_id)
        return render(request, 'votacao/novaopcao.html', {'questao': questao})

@permission_required('votacao.add_opcao', login_url=reverse_lazy('votacao:iniciarsessao'))
def apagarquestao(request, questao_id):
    questao = get_object_or_404(Questao, pk=questao_id)
    questao.delete()
    return HttpResponseRedirect(reverse('votacao:index'))

@permission_required('votacao.add_opcao', login_url=reverse_lazy('votacao:iniciarsessao'))
def apagaropcao(request, questao_id):
    questao = get_object_or_404(Questao, pk=questao_id)
    try:
        opcao_seleccionada = questao.opcao_set.get(pk=request.POST['opcao'])
    except (KeyError, Opcao.DoesNotExist):
        return render(request, 'votacao/detalhe.html', {'questao': questao, 'error_message': "Não escolheu uma opção",})
    else:
        opcao_seleccionada.delete()
        return HttpResponseRedirect(reverse('votacao:detalhe', args=(questao.id,)))

def registar(request):
    try:
        username = request.POST['username']
        password = request.POST['password']
        email = request.POST['email']
        course = request.POST['course']
        u = User.objects.create_user(username, password=password, email=email)
        a = Aluno(user=u, course=course)
        a.save()
        user = authenticate(username=username, password=password)
        return render(request, 'votacao/iniciarsessao.html')
    except MultiValueDictKeyError:
        return render(request, 'votacao/registar.html')

def iniciarsessao(request):
    try:
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)

        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse('votacao:index'))

        else:
            return render(request, 'votacao/registar.html')
    except MultiValueDictKeyError:
        return render(request, 'votacao/iniciarsessao.html')


def perfil(request):
    try:
        uploaded_file_url = request.user.foto.foto_url
        return render(request, 'votacao/perfil.html', {'uploaded_file_url': uploaded_file_url})
    except ObjectDoesNotExist:
        return render(request, 'votacao/perfil.html')


def logoutview(request):
    logout(request)
    return HttpResponseRedirect(reverse('votacao:index'))

@login_required(login_url='votacao/registar.html')
def fazer_upload(request):
    if request.method == 'POST' and request.FILES['myfile']:
        myfile = request.FILES['myfile']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename)
        u = request.user.user_id
        foto = Foto(user=u, foto_url=uploaded_file_url)
        foto.save()
        return render(request,'votacao/perfil.html', {'uploaded_file_url': uploaded_file_url})
    return render(request, 'votacao/perfil.html')


